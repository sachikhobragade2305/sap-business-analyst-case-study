
# User Stories

- As a customer service rep, I want to track order history quickly so that I can resolve customer queries faster.
- As an inventory manager, I want real-time stock updates so I can avoid stockouts and overstocking.
- As a CEO, I want a dashboard view of key metrics so I can make strategic decisions faster.
